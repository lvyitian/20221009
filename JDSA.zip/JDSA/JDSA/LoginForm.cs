﻿/*
 * 由SharpDevelop创建。
 * 用户： Administrator
 * 日期: 2022/10/9 星期日
 * 时间: 下午 6:35
 * 
 * 要改变这种模板请点击 工具|选项|代码编写|编辑标准头文件
 */
using System;
using System.Drawing;
using System.Windows.Forms;
using System.Threading;
using Kyozy.MiniblinkNet;

namespace JDSA
{
	/// <summary>
	/// Description of LoginForm.
	/// </summary>
	public partial class LoginForm : Form
	{
		public volatile bool isClosed;
		public WebView m_wke;
		public LoginForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			m_wke=new WebView();
			m_wke.Bind(this);
			this.m_wke.OnLoadingFinish+=(sen,eve)=>{
					if(eve.LoadingResult==Kyozy.MiniblinkNet.wkeLoadingResult.Succeeded)
					{
						if(Program.main.isDone)
							return;
						if(!eve.URL.StartsWith("https://cart.jd.com/"))
							return;
						Program.main.button1.Text="处理中: "+(Program.main.i+1)+"/"+Program.main.li.LongLength;
						if(Program.main.i>=Program.main.li.LongLength)
						{
							this.m_wke.StopLoading();
			            	this.m_wke.LoadHTML("");
			            	this.m_wke.StopLoading();
			            	if(MessageBox.Show("处理已完成，是否打开购物车？","询问",MessageBoxButtons.YesNo,MessageBoxIcon.Question,MessageBoxDefaultButton.Button1)==DialogResult.Yes)
			            	{
			            		Program.main.isDone=true;
			            		Program.main.Enabled=false;
			            	    Program.main.Visible=false;
			            		//this.m_wke.LoadURL("https://cart.jd.com/cart.action?null");
			            		m_wke.LoadFile(Application.ExecutablePath.Substring(0,Application.ExecutablePath.LastIndexOf('\\'))+"\\sum.html");
			            		this.Visible=true;
			            	}
							Program.main.button1.Text="选择商品列表";
					        Program.main.button1.Enabled=true;
					        return;
						}
						Program.main.i++;
						Program.main.loginForm.m_wke.StopLoading();
				        Program.main.loginForm.m_wke.LoadHTML("");
				        Program.main.loginForm.m_wke.StopLoading();
						while(true)
				        {
							if(Program.main.i>=Program.main.li.LongLength)
					        {
						      this.m_wke.StopLoading();
			                  this.m_wke.LoadHTML("");
			                  this.m_wke.StopLoading();
			                  if(MessageBox.Show("处理已完成，是否打开购物车？","询问",MessageBoxButtons.YesNo,MessageBoxIcon.Question,MessageBoxDefaultButton.Button1)==DialogResult.Yes)
			            	  {
			                  	Program.main.isDone=true;
			                  	Program.main.Enabled=false;
			            	    Program.main.Visible=false;
			            		//this.m_wke.LoadURL("https://cart.jd.com/cart.action?null");
			            		m_wke.LoadFile(Application.ExecutablePath.Substring(0,Application.ExecutablePath.LastIndexOf('\\'))+"\\sum.html");
			            		this.Visible=true;
			            	  }
						      Program.main.button1.Text="选择商品列表";
					          Program.main.button1.Enabled=true;
					       	  break;
					        }
					      try{
					        this.m_wke.LoadURL("https://cart.jd.com/gate.action?pid="+Program.main.li[Program.main.i].Substring(Program.main.li[Program.main.i].LastIndexOf("/")+1,Program.main.li[Program.main.i].LastIndexOf(".html")-(Program.main.li[Program.main.i].LastIndexOf("/")+1))+"&pcount=1&ptype=1");
					        break;
							}catch(Exception){Program.main.button1.Text="处理中: "+(Program.main.i+1)+"/"+Program.main.li.LongLength;Program.main.i++;}
				        }
					}else if(eve.LoadingResult!=Kyozy.MiniblinkNet.wkeLoadingResult.Canceled){
						this.m_wke.Reload();
					}
				};
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		void LoginFormFormClosed(object sender, FormClosedEventArgs e)
		{
			isClosed=true;
			try{
				this.Visible=false;
				Program.main.Enabled=true;
				Program.main.BringToFront();
			}catch(Exception){}
		}
		void LoginFormFormClosing(object sender, FormClosingEventArgs e)
		{
			e.Cancel=!isClosed;
			if(isClosed)
				Environment.Exit(0);
		}
		void LoginFormLoad(object sender, EventArgs e)
		{
			//m_wke.LoadURL("https://cart.jd.com/gate.action");
			//MessageBox.Show(Application.ExecutablePath.Substring(0,Application.ExecutablePath.LastIndexOf('\\'))+"\\");
			m_wke.LoadFile(Application.ExecutablePath.Substring(0,Application.ExecutablePath.LastIndexOf('\\'))+"\\index.html");
			m_wke.OnURLChange+=(s,ev)=>{
				if(isClosed)
					return;
				if(ev.URL.StartsWith(@"file:"))
					return;
				if(!ev.URL.Substring(8).StartsWith("passport.jd.com"))
				{
					LoginFormFormClosed(null,null);
				}
			};
		}
	}
}
