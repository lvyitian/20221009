﻿/*
 * 由SharpDevelop创建。
 * 用户： Administrator
 * 日期: 2022/10/9 星期日
 * 时间: 下午 6:25
 * 
 * 要改变这种模板请点击 工具|选项|代码编写|编辑标准头文件
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Threading;

namespace JDSA
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		public LoginForm loginForm;
		public volatile bool isDone;
		public volatile string[] li;
		public volatile int i;
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			this.FormBorderStyle=FormBorderStyle.FixedSingle;
			openFileDialog1.FileOk+=(s,ev)=>{
			  if(openFileDialog1.FileName!=null && openFileDialog1.FileName.Trim().Length!=0)
			  {
				button1.Enabled=false;
				var fs=openFileDialog1.OpenFile();
				byte[] buf=new byte[fs.Length];
				fs.Read(buf,0,buf.Length);
				var fl=System.Text.Encoding.UTF8.GetString(buf);
				li=fl.Split('\n');
				i=0;
				isDone=false;
				button1.Text="处理中: 0/"+li.LongLength;
				loginForm.m_wke.StopLoading();
				loginForm.m_wke.LoadHTML("");
				loginForm.m_wke.StopLoading();
				while(true)
				{
					if(i>=li.LongLength)
					{
						loginForm.m_wke.StopLoading();
			            loginForm.m_wke.LoadHTML("");
			            loginForm.m_wke.StopLoading();
			            if(MessageBox.Show("处理已完成，是否打开购物车？","询问",MessageBoxButtons.YesNo,MessageBoxIcon.Question,MessageBoxDefaultButton.Button1)==DialogResult.Yes)
			            {
			            	Program.main.isDone=true;
			            	this.Enabled=false;
			            	this.Visible=false;
			            	//loginForm.m_wke.LoadURL("https://cart.jd.com/cart.action?null");
			            	loginForm.m_wke.LoadFile(Application.ExecutablePath.Substring(0,Application.ExecutablePath.LastIndexOf('\\'))+"\\sum.html");
			            	loginForm.Visible=true;
			            }
						button1.Text="选择商品列表";
					    button1.Enabled=true;
						break;
					}
					try{
					loginForm.m_wke.LoadURL("https://cart.jd.com/gate.action?pid="+li[i].Substring(li[i].LastIndexOf("/")+1,li[i].LastIndexOf(".html")-(li[i].LastIndexOf("/")+1))+"&pcount=1&ptype=1");
					break;
					}catch(Exception){button1.Text="处理中: "+(i+1)+"/"+li.LongLength;i++;}
				}
			}
			};
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		void Button1Click(object sender, EventArgs e)
		{
			openFileDialog1.ShowDialog();
		}
		void MainFormLoad(object sender, EventArgs e)
		{
			this.Enabled=false;
			loginForm=new LoginForm();
			Thread t=new Thread(()=>Application.Run(loginForm)){ApartmentState=ApartmentState.STA,IsBackground=true};
			t.Start();
		}
	}
}
