﻿/*
 * 由SharpDevelop创建。
 * 用户： Administrator
 * 日期: 2022/10/9 星期日
 * 时间: 下午 6:25
 * 
 * 要改变这种模板请点击 工具|选项|代码编写|编辑标准头文件
 */
using System;
using System.Windows.Forms;

namespace JDSA
{
	/// <summary>
	/// Class with program entry point.
	/// </summary>
	internal sealed class Program
	{
		public static MainForm main;
		/// <summary>
		/// Program entry point.
		/// </summary>
		[STAThread]
		private static void Main(string[] args)
		{
			Control.CheckForIllegalCrossThreadCalls=false;
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);
			main=new MainForm();
			Application.Run(main);
		}
		
	}
}
